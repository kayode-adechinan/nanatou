import setuptools

setuptools.setup(
    name="nanatou",
    version="0.0.2",
    author="Kayode Adechinan",
    author_email="kayode.adechinan@gmail.com",
    description="to my lover",
    packages=setuptools.find_packages(),
    install_requires=[
          'requests',
      ],
    license='MIT',
    zip_safe=False
)
